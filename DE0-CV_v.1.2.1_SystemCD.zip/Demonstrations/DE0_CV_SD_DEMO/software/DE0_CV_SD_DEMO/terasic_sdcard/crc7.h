#ifndef CRC7_H_
#define CRC7_H_

alt_u8 crc7(alt_u8 crc, const alt_u8 *buffer, int len);

#endif /*CRC7_H_*/
