#ifndef CRC16_H_
#define CRC16_H_

alt_u16 crc16(const alt_u8 *buffer, int len);

#endif /*CRC16_H_*/
